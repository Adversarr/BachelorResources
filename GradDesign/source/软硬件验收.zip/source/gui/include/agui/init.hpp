#pragma once
#include <string>
namespace acg::gui {

void hook_default_gui_environment(std::string app_name);

}  // namespace acg::gui
