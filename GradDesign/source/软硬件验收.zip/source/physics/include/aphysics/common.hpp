#pragma once

#include <acore/math/common.hpp>
