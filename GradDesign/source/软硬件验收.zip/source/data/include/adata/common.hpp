#pragma once

#include <string>
namespace acg::data {
std::string get_data_dir();
}
