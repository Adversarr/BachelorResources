#include <adata/common.hpp>

namespace acg::data {
std::string get_data_dir() { return DATA_DIR; }
}  // namespace acg::data
