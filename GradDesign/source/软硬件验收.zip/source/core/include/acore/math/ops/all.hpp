#pragma once

#include "kronecker.hpp"
