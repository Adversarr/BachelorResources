/****************************************
 *
 * @brief Type Definitions for Geometry and Topology.
 *
 ****************************************/


#pragma once
#include "../math/common.hpp"

namespace acg::geometry {

}  // namespace acg::geometry
