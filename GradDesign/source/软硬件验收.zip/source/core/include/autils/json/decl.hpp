#pragma once
#include <nlohmann/json.hpp>
#include "../common.hpp"

namespace acg::utils {

using Json = nlohmann::json;

}
