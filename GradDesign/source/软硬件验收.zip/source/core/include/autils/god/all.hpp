#pragma once

#include "god.hpp"
#include "algorithms.hpp"
