#pragma once
#include <vector>
#include <string>

namespace acg::utils::io {

std::vector<char> read_binary_file(std::string path);

}
